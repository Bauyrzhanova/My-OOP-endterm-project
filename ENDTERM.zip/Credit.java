package com.company;

public class Credit {

    private final int user_id;
    private final int id;
    private int totalSum;
    private int paid;
    private int resldue;
    private int monthlyPayment;
    private double percent;
    private long givenDate;
    private long dueDate;

    public Credit(int user_id, int id, int totalSum, int paid, int resldue, int monthlyPayment, double percent, long givenDate, long dueDate) {
        this.user_id = user_id;
        this.id = id;
        this.totalSum = totalSum;
        this.paid = paid;
        this.resldue = resldue;
        this.monthlyPayment = monthlyPayment;
        this.percent = percent;
        this.givenDate = givenDate;
        this.dueDate = dueDate;
    }


    public int getUser_id() {
        return user_id;
    }

    public int getId() {
        return id;
    }

    public int getTotalSum() {
        return totalSum;
    }

    public int getPaid() {
        return paid;
    }

    public int getResldue() {
        return resldue;
    }

    public int getMonthlyPayment() {
        return monthlyPayment;
    }

    public double getPercent() {
        return percent;
    }

    public long getGivenDate() {
        return givenDate;
    }

    public long getDueDate() {
        return dueDate;
    }
}
