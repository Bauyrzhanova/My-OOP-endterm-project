package com.company;

public class Admin extends User {


    public Admin() {
    }

    public Admin(Integer id, String name, String surname) {
        super(id, name, surname);
    }



}
